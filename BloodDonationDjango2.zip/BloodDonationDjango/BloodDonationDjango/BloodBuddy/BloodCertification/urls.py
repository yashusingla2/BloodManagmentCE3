from django.urls import path
from . import views

urlpatterns = [
    # ... your other paths
    path('certificate/', views.generate_certificate, name='generate_certificate'),
]
