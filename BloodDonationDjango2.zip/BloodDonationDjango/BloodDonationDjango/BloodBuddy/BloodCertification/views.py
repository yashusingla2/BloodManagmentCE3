import uuid
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import BloodCertificate

@login_required
def generate_certificate(request):
    user = request.user

    # Check if a certificate already exists
    certificate, created = BloodCertificate.objects.get_or_create(
        user=user,
        defaults={
            'certificate_id': str(uuid.uuid4()).split('-')[0],
            'issued': True,
        }
    )

    return render(request, 'certificate.html', {'certificate': certificate})
