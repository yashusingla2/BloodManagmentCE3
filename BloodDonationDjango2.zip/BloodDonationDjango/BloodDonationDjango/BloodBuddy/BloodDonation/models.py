from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission

# Common blood group choices
BLOOD_GROUP_CHOICES = [
    ('A+', 'A+'), ('A-', 'A-'),
    ('B+', 'B+'), ('B-', 'B-'),
    ('AB+', 'AB+'), ('AB-', 'AB-'),
    ('O+', 'O+'), ('O-', 'O-'),
]

# Custom user model
class CustomUser(AbstractUser):
    groups = models.ManyToManyField(Group, related_name='customuser_set', blank=True)
    user_permissions = models.ManyToManyField(Permission, related_name='customuser_permissions', blank=True)

# Donor model
class Donor(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    blood_group = models.CharField(max_length=3, choices=BLOOD_GROUP_CHOICES)
    location = models.CharField(max_length=255)
    available = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.user.username} - {self.blood_group} - {self.location}"

# Blood request model
class BloodRequest(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    blood_group = models.CharField(max_length=3, choices=BLOOD_GROUP_CHOICES)
    location = models.CharField(max_length=255)
    reason = models.TextField()
    request_date = models.DateTimeField(auto_now_add=True)
    matched = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.name} needs {self.blood_group} at {self.location}"

# Donation model
class Donation(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    blood_group = models.CharField(max_length=3, choices=BLOOD_GROUP_CHOICES)
    location = models.CharField(max_length=255)
    available = models.BooleanField(default=True)
    donation_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} donated {self.blood_group} at {self.location}"
