from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('donate_blood/', views.donate_blood, name='donate_blood'),
    path('request_blood/', views.request_blood, name='request_blood'),
    path('request_success/', views.request_success, name='request_success'),
    path('about/', views.about, name='about'),
    path('login/', views.login_view, name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('register/', views.register, name='register'),
    path('dashboard/',views.dashboard,name="dashboard"),
    path('certificate/',views.certificate,name="certificate"),
    
]
