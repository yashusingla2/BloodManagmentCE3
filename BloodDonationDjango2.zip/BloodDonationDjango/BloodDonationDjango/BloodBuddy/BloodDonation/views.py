from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import CustomUserCreationForm, BloodRequestForm, DonationForm
from .models import Donor, BloodRequest
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import login_required
from BloodCertification.models import BloodCertificate
from django.contrib import messages



def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')  # or 'dashboard' if you have that
    else:
        form = AuthenticationForm()
    
    return render(request, 'login.html', {'form': form})

import uuid


@login_required
def donate_blood(request):
    if request.method == 'POST':
        blood_group = request.POST.get('blood_group')
        location = request.POST.get('location')

        Donor.objects.create(
            user=request.user,
            blood_group=blood_group,
            location=location,
            available=True
        )

        # 🔽 Create certificate if not already issued
        if not BloodCertificate.objects.filter(user=request.user).exists():
            BloodCertificate.objects.create(
                user=request.user,
                certificate_id=str(uuid.uuid4())[:8],  # Generate unique ID
                issued=True
            )

        return redirect('request_success')
    return render(request, 'donate_blood.html')

def request_blood(request):
    if request.method == 'POST':
        form = BloodRequestForm(request.POST)
        if form.is_valid():
            blood_request = form.save(commit=False)
            blood_request.user = request.user
            blood_request.name = request.user.username
            blood_request.save()

            # Try to match donor
            donor = Donor.objects.filter(
                blood_group=blood_request.blood_group,
                location=blood_request.location,
                available=True
            ).first()

            if donor:
                blood_request.matched = True
                blood_request.save()

            return redirect('request_success')
    else:
        form = BloodRequestForm()
    return render(request, 'request_blood.html', {'form': form})

def request_success(request):
    return render(request, 'request_success.html')

def about(request):
    return render(request, 'about.html')

import requests
from django.shortcuts import render
from .models import BloodRequest, Donation

def dashboard(request):
    # --- Local DB queries ---
    blood_requests_db = BloodRequest.objects.all()
    donations_db = Donation.objects.all()

    # --- Fetch from external API (Flask) ---
    try:
        api_response = requests.get('http://127.0.0.1:5000/api/recipients')
        api_requests = api_response.json() if api_response.status_code == 200 else []
        print(api_requests)
    except Exception as e:
        api_requests = []

    try:
        donor_response = requests.get('http://127.0.0.1:5000/api/donors')
        api_donors = donor_response.json() if donor_response.status_code == 200 else []
        print(api_donors)
    except Exception as e:
        api_donors = []

    # --- Combine data (merge lists) ---
    all_blood_requests = list(blood_requests_db) + api_requests
    all_donations = list(donations_db) + api_donors

    context = {
        "total_requests": len(all_blood_requests),
        "total_donors": len(all_donations),
        "blood_requests": all_blood_requests,
        "donations": all_donations,
    }
    return render(request, 'dashboard.html', context)

@login_required
def certificate(request):
    try:
        certificate = BloodCertificate.objects.filter(user=request.user).latest('donation_date')
        return render(request, 'certificate.html', {'certificate': certificate})
    except BloodCertificate.DoesNotExist:
        messages.error(request, "No certificate found. Please donate blood first.")
        return redirect('home')



