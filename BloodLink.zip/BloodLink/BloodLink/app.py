from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt  # Import Bcrypt
from flask_restful import *
from flask import jsonify
app = Flask(__name__)



# Configure database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///donor_recipient.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'your_secret_key'  # Required for session management
db = SQLAlchemy(app)

# Initialize LoginManager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'  # Redirect to login if the user is not authenticated

# Initialize Bcrypt
bcrypt = Bcrypt(app)

api=Api(app)
# Database Models

# User Model (for login/signup)
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

# Donor Model
class Donor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    blood_type = db.Column(db.String(5), nullable=False)
    location = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<Donor {self.name}>'
# Recipient Model
class Recipient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), nullable=False)
    blood_type = db.Column(db.String(10), nullable=False)
    location = db.Column(db.String(100), nullable=False)

# Load user for login_manager
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes

# Home Page Route
@app.route('/')
def index():
    return render_template('index.html')

# About Us Page Route
@app.route('/about')
def about():
    return render_template('aboutus.html')

# Login Page Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Check if user exists
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):  # Use bcrypt to check password
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash('Invalid login credentials')
    
    return render_template('login.html')

# Signup Page Route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        # Check if passwords match
        if password != confirm_password:
            flash('Passwords do not match')
            return redirect(url_for('signup'))
        
        # Check if user already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already exists')
            return redirect(url_for('signup'))
        
        # Hash the password using bcrypt
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')  # Use bcrypt to hash password
        
        # Create a new user
        new_user = User(username=username, email=email, password=hashed_password)
        
        db.session.add(new_user)
        db.session.commit()
        
        return redirect(url_for('login'))
    
    return render_template('signup.html')

# Donate Page Route
@app.route('/donate', methods=['GET', 'POST'])
@login_required
def donate():
    if request.method == 'POST':
        # Capture form data
        name = request.form['name']
        email = request.form['email']
        blood_type = request.form['blood_type']
        location = request.form['location']

        # Create a new Donor record
        new_donor = Donor(name=name, email=email, blood_type=blood_type, location=location)

        # Add to the session and commit
        db.session.add(new_donor)
        db.session.commit()

        # Redirect after successful donation submission
        return redirect(url_for('index'))  # Or any other page you want to redirect after submission
    
    # If it's a GET request, render the donation form
    return render_template('donate.html')


@app.route('/recipient', methods=['GET', 'POST'])
@login_required
def recipient():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        blood_type = request.form['blood_type']
        location = request.form['location']
        
        # Save recipient information to the database
        new_recipient = Recipient(name=name, email=email, blood_type=blood_type, location=location)
        db.session.add(new_recipient)
        db.session.commit()
        
        return redirect(url_for('index'))
       
    
    return render_template('recieve.html')  # Render the recipient form

# Donors Page Route
@app.route('/donors')
@login_required
def donors():
    all_donors = Donor.query.all()
    return render_template('donors.html', donors=all_donors)

# Logout Route
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/community', methods=['GET', 'POST'])
def community():
    blood_type = request.args.get('blood_type')  # Get the selected blood type from query params
    recipients = Recipient.query
    donors = Donor.query
    
    # If a blood type is provided, filter recipients and donors by that blood type
    if blood_type:
        recipients = recipients.filter_by(blood_type=blood_type)
        donors = donors.filter_by(blood_type=blood_type)
    
    # Fetch the filtered lists from the database
    recipients = recipients.all()
    donors = donors.all()

    return render_template('community.html', recipients=recipients, donors=donors, selected_blood_type=blood_type)

class UserResource(Resource):
    def get(self):
        users = User.query.all()
        return jsonify([
            {
                'id': u.id,
                'username': u.username,
                'email': u.email
            } for u in users
        ])

    def post(self):  # Signup
        data = request.get_json()
        hashed_password = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        new_user = User(username=data['username'], email=data['email'], password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        return {"message": "User created successfully"}, 201

class LoginResource(Resource):
    def post(self):
        data = request.get_json()
        user = User.query.filter_by(email=data['email']).first()
        if user and bcrypt.checkpw(data['password'].encode('utf-8'), user.password.encode('utf-8')):
            return {"message": "Login successful", "user_id": user.id}, 200
        return {"message": "Invalid credentials"}, 401

    
class DonorResource(Resource):
    def get(self):
        donors = Donor.query.all()
        return jsonify([{
            'id': d.id,
            'name': d.name,
            'email': d.email,
            'blood_type': d.blood_type,
            'location': d.location
        } for d in donors])

    def post(self):
        data = request.get_json()
        new_donor = Donor(**data)
        db.session.add(new_donor)
        db.session.commit()
        return {"message": "Donor added"}, 201
    

class RecipientResource(Resource):
    def get(self):
        recipients = Recipient.query.all()
        return jsonify([{
            'id': r.id,
            'name': r.name,
            'email': r.email,
            'blood_type': r.blood_type,
            'location': r.location
        } for r in recipients])

    def post(self):
        data = request.get_json()
        new_recipient = Recipient(**data)
        db.session.add(new_recipient)
        db.session.commit()
        return {"message": "Recipient added"}, 201
    
api.add_resource(UserResource, '/api/users')
api.add_resource(LoginResource, '/api/login') 
api.add_resource(DonorResource, '/api/donors')
api.add_resource(RecipientResource, '/api/recipients')

if __name__ == '__main__':
    with app.app_context():  # Create the app context before calling db.create_all()
        db.create_all()  # Creates database tables
    app.run(debug=True)
